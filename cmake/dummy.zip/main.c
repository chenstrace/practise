#include <stdio.h>
#include "date.h"

int main() {
	puts(BUILD_DATE);
	return 0;
}
