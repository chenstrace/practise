<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
#ifndef ${GUARD_NAME}
#define ${GUARD_NAME}

#endif
