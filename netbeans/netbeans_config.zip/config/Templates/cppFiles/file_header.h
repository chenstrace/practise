<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">
#ifndef ${GUARD_NAME}
#define ${GUARD_NAME}

#endif
