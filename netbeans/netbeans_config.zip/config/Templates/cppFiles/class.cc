<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">
#include ${QUOTES}${NAME}.${DEFAULT_HEADER_EXT}${QUOTES}

${CLASSNAME}::${CLASSNAME}() {
}

${CLASSNAME}::${CLASSNAME}(const ${CLASSNAME}& orig) {
}

${CLASSNAME}::~${CLASSNAME}() {
}

