import smbclient
import os
import argparse
import sys

def download_smb_dir(remote_dir, local_dir):
    """
    Recursively download all files from SMB share, keeping the folder structure.
    """
    os.makedirs(local_dir, exist_ok=True)

    for entry in smbclient.listdir(remote_dir):
        remote_path = os.path.join(remote_dir, entry)
        local_path = os.path.join(local_dir, entry)

        if smbclient.path.isdir(remote_path):  # corrected
            print(f"Entering directory: {remote_path}")
            download_smb_dir(remote_path, local_path)
        else:
            print(f"Downloading file: {remote_path} -> {local_path}")
            with smbclient.open_file(remote_path, mode='rb') as remote_file, \
                 open(local_path, 'wb') as local_file:
                for chunk in iter(lambda: remote_file.read(4096), b''):
                    local_file.write(chunk)

def download_smb_file(remote_file_path, local_file_path):
    """
    Download a single file from SMB share.
    """
    os.makedirs(os.path.dirname(local_file_path) or ".", exist_ok=True)
    print(f"Downloading single file: {remote_file_path} -> {local_file_path}")
    with smbclient.open_file(remote_file_path, mode='rb') as remote_file, \
         open(local_file_path, 'wb') as local_file:
        for chunk in iter(lambda: remote_file.read(4096), b''):
            local_file.write(chunk)

def build_smb_path(server, relative_path):
    """
    Build a full SMB path from server and relative path.
    Example: server=10.255.255.176, relative_path=root\\chenjili
    -> \\\\10.255.255.176\\root\\chenjili
    """
    return f"\\\\{server}\\{relative_path}"

def main():
    parser = argparse.ArgumentParser(description="Download files from SMB share.")

    # SMB connection arguments with default info in help
    parser.add_argument(
        "--server",
        help="SMB server address (default: 10.255.255.176)",
        default="10.255.255.176"
    )
    parser.add_argument(
        "--username",
        help="SMB username (default: root)",
        default="root"
    )
    parser.add_argument(
        "--password",
        help="SMB password",
        default=None
    )

    # File/Directory selection arguments (relative path)
    parser.add_argument(
        "--remote-dir",
        help="Relative path of remote SMB directory (default: root\\chenjili)",
        default=None
    )
    parser.add_argument(
        "--remote-file",
        help="Relative path of remote SMB file (e.g., root\\chenjili\\file.txt)",
        default=None
    )
    parser.add_argument(
        "--local-dir",
        help="Local directory to save files (default: current directory)",
        default="."
    )

    args = parser.parse_args()

    # Set default directory if neither remote-dir nor remote-file provided
    if args.remote_dir is None and args.remote_file is None:
        args.remote_dir = "root\\chenjili"

    # Validate arguments: cannot specify both
    if args.remote_dir is not None and args.remote_file is not None:
        print("Error: --remote-dir and --remote-file cannot be used together.")
        sys.exit(1)

    # Register SMB session
    smbclient.register_session(server=args.server, username=args.username, password=args.password)

    if args.remote_file:
        smb_path = build_smb_path(args.server, args.remote_file)
        print(f"Full SMB file path: {smb_path}")

        # Normalize backslashes and extract filename
        normalized_path = args.remote_file.replace("\\", "/")
        filename = os.path.basename(normalized_path)
        local_path = os.path.join(args.local_dir, filename)

        download_smb_file(smb_path, local_path)
    else:
        smb_path = build_smb_path(args.server, args.remote_dir)
        print(f"Full SMB directory path: {smb_path}")
        download_smb_dir(smb_path, args.local_dir)

    print("Download completed successfully.")

if __name__ == "__main__":
    main()

