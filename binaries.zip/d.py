from flask import Flask, request, jsonify
import os
import json
import zipfile
import traceback
import shutil
import subprocess

app = Flask(__name__)

PORT = 8000
UPLOAD_DIR = "/tmp/deployments"  # 上传目录
os.makedirs(UPLOAD_DIR, exist_ok=True)


def execute_command(command):
    """Execute a shell command and return its output."""
    try:
        print(f"Executing command: {command}")
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"Command failed with error: {result.stderr}")
            raise Exception(f"Command failed with error: {result.stderr}")
        print(f"Command output: {result.stdout}")
        return result.stdout
    except Exception as e:
        print(f"Error executing command '{command}': {str(e)}")
        raise Exception(f"Error executing command '{command}': {str(e)}")


@app.route('/deploy', methods=['POST'])
def deploy():
    try:
        print("Received deployment request")
        # 1. 检查是否有文件上传
        if 'file' not in request.files:
            print("No file in request")
            return jsonify({'error': 'No file uploaded'}), 400

        file = request.files['file']
        print(f"Received file: {file.filename}")

        # 2. 检查文件名是否为空
        if file.filename == '':
            print("Empty filename")
            return jsonify({'error': 'No filename'}), 400

        # 3. 保存上传的文件
        filepath = os.path.join(UPLOAD_DIR, file.filename)
        print(f"Saving file to: {filepath}")
        file.save(filepath)

        # 4. 处理上传的文件, 并获取部署的文件列表
        deployed_files = process_package(filepath)
        print(f"Deployment successful. Deployed files: {deployed_files}")

        return jsonify({'message': 'Deployment successful', 'deployed_files': deployed_files}), 200

    except Exception as e:
        print(f"Deployment failed: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")
        return jsonify({'error': str(e), 'trace': traceback.format_exc()}), 500


def process_package(filepath):
    """解压文件并根据描述文件部署."""
    deployed_files = []  # 用于存储部署的文件路径

    try:
        print(f"Processing package: {filepath}")
        with zipfile.ZipFile(filepath, "r") as zip_ref:
            print("Extracting package contents")
            zip_ref.extractall(UPLOAD_DIR)

        # 读取部署配置
        config_file_path = os.path.join(UPLOAD_DIR, "deployment_config.json")
        print(f"Reading deployment config from: {config_file_path}")
        with open(config_file_path, "r") as f:
            deployment_config = json.load(f)
            
        file_mappings = deployment_config["file_mappings"]
        before_deploy = deployment_config.get("before_deploy")
        after_deploy = deployment_config.get("after_deploy")
        print(f"Before deploy command: {before_deploy}")
        print(f"After deploy command: {after_deploy}")

        # 执行部署前命令
        if before_deploy:
            print("Executing before deploy command")
            execute_command(before_deploy)

        # 转换路径
        for mapping in file_mappings:
            mapping["local"] = mapping["local"].replace("\\", "/")
            mapping["remote"] = mapping["remote"].replace("\\", "/")

        # 应用文件映射
        for mapping in file_mappings:
            local_path = os.path.join(UPLOAD_DIR, mapping["local"])
            remote_path = mapping["remote"]

            # 确保目标目录存在
            remote_dir = os.path.dirname(remote_path)
            os.makedirs(remote_dir, exist_ok=True)

            # 移动文件
            print(f"Moving {local_path} to {remote_path}")
            shutil.move(local_path, remote_path)

            deployed_files.append(remote_path)

        # 执行部署后命令
        if after_deploy:
            print("Executing after deploy command")
            execute_command(after_deploy)

    except Exception as e:
        print(f"Error processing package: {str(e)}")
        print(f"Traceback: {traceback.format_exc()}")
        raise Exception(f"Error processing package: {e}")

    finally:
        # 清理临时文件
        try:
            print("Cleaning up temporary files")
            os.remove(filepath)
            os.remove(config_file_path)
            shutil.rmtree(UPLOAD_DIR, ignore_errors=True)
            os.makedirs(UPLOAD_DIR, exist_ok=True)
        except Exception as e:
            print(f"Cleanup failed: {e}")

    return deployed_files


if __name__ == '__main__':
    print(f"Starting deployment server on port {PORT}")
    app.run(debug=False, host='0.0.0.0', port=PORT)
