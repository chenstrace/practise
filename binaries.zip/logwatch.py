#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import time
import datetime
import argparse
import subprocess
import sys
import queue
import socket
from pathlib import Path
from typing import Dict
import threading

def timestamp():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

def check_dependencies():
    required = {
        "watchdog": "watchdog",
        "requests": "requests",
        "pyroute2": "pyroute2"
    }
    missing = []
    for module, package in required.items():
        try:
            __import__(module)
        except ImportError:
            missing.append(package)
    
    if missing:
        print(f"{timestamp()} Missing dependencies: {', '.join(missing)}. Attempting to install...")
        for package in missing:
            success = False
            cmds = [
                [sys.executable, "-m", "pip", "install", package],
                ["pip3", "install", package],
                ["pip", "install", package]
            ]
            for cmd in cmds:
                try:
                    subprocess.check_call(cmd)
                    success = True
                    break
                except Exception:
                    continue
            
            if not success:
                print(f"{timestamp()} Error: Could not install {package}. Please run 'pip install {package}' manually.")
                sys.exit(1)
        print(f"{timestamp()} Dependencies installed successfully.\n")

check_dependencies()

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import requests
from pyroute2 import IPRoute

SCAN_INTERVAL = 1.0

# -------------------------

def get_local_ip():
    """Try to get management IP or first non-loopback IP using pyroute2."""
    try:
        with IPRoute() as ipr:
            # 1. Try 'mgmt' interface first
            idx = ipr.link_lookup(ifname="mgmt")
            if idx:
                addrs = ipr.get_addr(index=idx[0], family=socket.AF_INET)
                if addrs:
                    return addrs[0].get_attr('IFA_ADDRESS')
            
            # 2. Fallback: Take the first non-loopback interface with an IPv4
            for addr in ipr.get_addr(family=socket.AF_INET):
                ip = addr.get_attr('IFA_ADDRESS')
                label = addr.get_attr('IFA_LABEL') or ""
                # Skip loopback and common indicators of lo
                if ip == "127.0.0.1" or label.startswith("lo"):
                    continue
                return ip
    except Exception:
        pass
    return "unknown"
class FileState:
    def __init__(self, path: Path, offset: int = 0):
        self.path = path
        self.offset = offset
        self.line_num = 0
        # Traceback parsing state persistence
        self.buffer = []
        self.inside_traceback = False
        self.tb_start_line = 0
        self.last_update = time.time()

class LogHandler(FileSystemEventHandler):
    def __init__(self, monitor):
        self.monitor = monitor

    def on_created(self, event):
        if event.is_directory:
            return
        p = Path(event.src_path)
        if p.suffix == ".log" and not self.monitor._is_skipped(p):
            self.monitor.add_file(p, tail=False)

    def on_modified(self, event):
        if event.is_directory:
            return
        p = Path(event.src_path)
        if p.suffix == ".log" and not self.monitor._is_skipped(p):
            self.monitor.check_file(p)

class LogMonitor:
    def __init__(self, dirs, tg_token=None, tg_chat_id=None, skip_files=None, interval=10):
        self.watch_dirs = [Path(d).resolve() for d in dirs]
        self.skip_files = [Path(f).resolve() for f in (skip_files or [])]
        self.files: Dict[Path, FileState] = {}
        self.lock = threading.Lock()
        self.tg_token = tg_token
        self.tg_chat_id = tg_chat_id
        self.tg_queue = queue.Queue()
        self.local_ip = get_local_ip()
        self.rate_limit_interval = interval * 60
        self.sent_notifications: Dict[tuple, float] = {}

    def start(self):
        print(f"{timestamp()} [INFO] LogMonitor started (IP: {self.local_ip}, Tail mode: ON)", flush=True)
        if self.tg_token and self.tg_chat_id:
            print(f"{timestamp()} [INFO] Telegram notifications enabled (Rate limit: 1s)", flush=True)
            threading.Thread(target=self._tg_worker, daemon=True).start()

        observer = Observer()
        handler = LogHandler(self)

        # 1. Initial scan: add existing files and start from END (tail)
        for d in self.watch_dirs:
            if not d.exists():
                print(f"{timestamp()} [ERROR] Dir does not exist: {d}", flush=True)
                continue
            
            # Initial track of already existing files
            for f in d.glob("*.log"):
                if not self._is_skipped(f):
                    self.add_file(f, tail=True)

            observer.schedule(handler, str(d), recursive=False)
            print(f"{timestamp()} [INFO] Watching {d}", flush=True)

        observer.start()
        threading.Thread(target=self._fallback_scan, daemon=True).start()

        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            observer.stop()
            observer.join()
            print(f"{timestamp()} [INFO] Stopped")

    def _tg_worker(self):
        while True:
            msg = self.tg_queue.get()
            if msg is None:
                break
            
            url = f"https://api.telegram.org/bot{self.tg_token}/sendMessage"
            payload = {
                "chat_id": self.tg_chat_id, 
                "text": msg
            }
            try:
                response = requests.post(url, data=payload, timeout=10)
                if response.status_code == 429:
                    wait = float(response.json().get('parameters', {}).get('retry_after', 1))
                    time.sleep(wait)
                    self.tg_queue.put(msg)
                elif response.status_code != 200:
                    print(f"{timestamp()} [ERROR] Telegram API Error: {response.status_code} - {response.text}")
                else:
                    response.raise_for_status()
            except Exception as e:
                print(f"{timestamp()} [ERROR] Failed to send Telegram: {e}")
            
            time.sleep(1.0)
            self.tg_queue.task_done()

    def _is_skipped(self, p: Path):
        try:
            return p.resolve() in self.skip_files
        except Exception:
            return False

    def _fallback_scan(self):
        while True:
            now = time.time()
            for d in self.watch_dirs:
                if not d.exists():
                    continue
                for f in d.glob("*.log"):
                    if self._is_skipped(f):
                        continue
                    if f not in self.files:
                        self.add_file(f, tail=False)
                    else:
                        self.check_file(f)
            
            # Periodic flush for idle tracebacks
            with self.lock:
                for fs in self.files.values():
                    if fs.buffer and (now - fs.last_update > 0.5):
                        self.output(fs.path, "".join(fs.buffer), fs.tb_start_line)
                        fs.buffer = []
                        fs.inside_traceback = False
            
            time.sleep(SCAN_INTERVAL)

    def add_file(self, path: Path, tail=False):
        with self.lock:
            if path in self.files:
                return
            try:
                # If tail=True, start from current end.
                # If tail=False (new file), start from 0.
                offset = 0
                if tail:
                    try:
                        offset = path.stat().st_size
                    except Exception:
                        offset = 0
                
                fs = FileState(path, offset=offset)
                self.files[path] = fs
                print(f"{timestamp()} [INFO] monitoring {path.name} (mode: {'tail' if tail else 'new file'})", flush=True)
            except Exception:
                pass

    def check_file(self, path: Path):
        with self.lock:
            fs = self.files.get(path)
            if not fs:
                self.add_file(path, tail=False)
                return
            try:
                size = path.stat().st_size
            except FileNotFoundError:
                self.files.pop(path, None)
                return

            if size < fs.offset:
                fs.offset = 0
                fs.line_num = 0

            if size > fs.offset:
                self.read_new(fs)

    def read_new(self, fs: FileState):
        try:
            with fs.path.open("r", errors="ignore") as f:
                f.seek(fs.offset)
                data = f.read()
                fs.offset = f.tell()

                if not data:
                    return

                fs.last_update = time.time()
                lines = data.splitlines(keepends=True)
                
                LOG_RECORD_RE = re.compile(r'^\[?\d{4}-\d{2}-\d{2}')
                TB_START_PATTERN = "Traceback (most recent call last):"

                for line in lines:
                    fs.line_num += 1
                    
                    # New log record (timestamp) indicates end of any previous traceback
                    if LOG_RECORD_RE.match(line):
                        if fs.buffer and TB_START_PATTERN not in line:
                            self.output(fs.path, "".join(fs.buffer), fs.tb_start_line)
                            fs.buffer = []
                            fs.inside_traceback = False
                    
                    if TB_START_PATTERN in line:
                        is_continuation = False
                        if fs.buffer:
                            # Look back at last few lines in buffer for chain indicators
                            tail = "".join(fs.buffer[-5:])
                            if any(x in tail for x in ["During handling", "above exception", "direct cause"]):
                                is_continuation = True
                        
                        # If a new Traceback starts and it's NOT a continuation, flush previous
                        if fs.buffer and not is_continuation:
                            self.output(fs.path, "".join(fs.buffer), fs.tb_start_line)
                            fs.buffer = []
                        
                        if not is_continuation:
                            fs.tb_start_line = fs.line_num
                        
                        fs.inside_traceback = True
                        fs.buffer.append(line)
                        continue

                    if fs.inside_traceback:
                        fs.buffer.append(line)

        except Exception:
            pass

    def output(self, path: Path, text, log_line):
        matches = re.findall(r'File "(.+?)", line (\d+)', text)
        if matches:
            src_file, line = matches[-1]
        else:
            lines = text.strip().splitlines()
            src_file, line = (lines[-1] if lines else "unknown"), "0"

        now = time.time()
        current_time = datetime.datetime.fromtimestamp(now).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        abs_path = path.resolve()

        # 1. Console Output
        print("\n" + "=" * 70, flush=True)
        print(f"File: {abs_path} (Line {log_line})", flush=True)
        print(f"IP: {self.local_ip}", flush=True)
        print(f"Time: {current_time}", flush=True)
        print(f"Location: {src_file}:{line}", flush=True)
        print("\n" + text.rstrip(), flush=True)
        print("=" * 70 + "\n", flush=True)

        # 2. Telegram Queue (with rate limit)
        if self.tg_token and self.tg_chat_id:
            key = (src_file, line)
            last_sent = self.sent_notifications.get(key, 0)
            if now - last_sent >= self.rate_limit_interval:
                self.sent_notifications[key] = now
                trimmed_text = text.rstrip()[:3500]
                tg_msg = (
                    f"IP: {self.local_ip}\n"
                    f"File: {abs_path} (Line {log_line})\n"
                    f"Time: {current_time}\n"
                    f"Location: {src_file}:{line}\n\n"
                    f"{trimmed_text}"
                )
                self.tg_queue.put(tg_msg)
            else:
                print(f"{timestamp()} [SKIP] Telegram notification rate limited for {src_file}:{line}")

def main():
    parser = argparse.ArgumentParser(
        description="Monitor log files and send Python tracebacks to Telegram.",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("dirs", nargs="*", default=["."], help="Directories to watch")
    parser.add_argument("--token", required=True, help="Telegram Bot Token")
    parser.add_argument("--chat-id", required=True, help="Telegram Chat ID")
    parser.add_argument("--skip-file", nargs="+", default=[], help="Log files to ignore")
    parser.add_argument("--interval", type=int, default=10, help="Rate limit interval in minutes for the same exception (default: 10)")
    
    args = parser.parse_args()

    monitor = LogMonitor(
        args.dirs, 
        tg_token=args.token, 
        tg_chat_id=args.chat_id,
        skip_files=args.skip_file,
        interval=args.interval
    )
    monitor.start()

if __name__ == "__main__":
    # Start logwatch, configure it to ignore two files, and set the duplicate message frequency limit to 5 minutes.
    # python3 logwatch.py /var/log --token YOUR_TOKEN --chat-id YOUR_ID --skip-file ignored1.log ignored2.log --interval 5
    main()
